var searchData=
[
  ['x',['x',['../structbomb.html#a6150e0515f7202e2fb518f7206ed97dc',1,'bomb::x()'],['../structmouse.html#a6150e0515f7202e2fb518f7206ed97dc',1,'mouse::x()'],['../structplayer.html#a6150e0515f7202e2fb518f7206ed97dc',1,'player::x()'],['../struct_sprite.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Sprite::x()']]],
  ['x_5fendpos',['x_endpos',['../structbomb.html#a2e391fa3218fc2204615a6c63d02af87',1,'bomb']]],
  ['x_5fovf',['x_ovf',['../structmouse__packet.html#a6eff97cd85d3d2081ca37c96fc71564f',1,'mouse_packet']]],
  ['x_5fsign',['x_sign',['../structmouse__packet.html#afafa8b75fed0e0ab9ff250e558be627b',1,'mouse_packet']]],
  ['x_5fvalue',['x_value',['../structmouse__packet.html#a426861976975ff8d4ecaef02395633e7',1,'mouse_packet']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#a047d8f41434f02589d0c9b90b17c67eb',1,'__attribute__']]],
  ['xmax',['xmax',['../struct_limits.html#a3bd9aad0bd6c391604e7a27d57c21d3f',1,'Limits']]],
  ['xpos',['xpos',['../structbomb.html#a4c8fb3f1c1ae597ee856290390ebc274',1,'bomb']]],
  ['xresolution',['XResolution',['../struct____attribute____.html#a16f6408e5a85c7a7785a0cee64b6a219',1,'__attribute__::XResolution()'],['../struct_bitmap_info_header.html#ac6eaeb4c0876cf6cd899f41fe3c25ff5',1,'BitmapInfoHeader::xResolution()']]],
  ['xspeed',['xspeed',['../struct_sprite.html#a31f88fdc0f724768624f33a2e63b5579',1,'Sprite']]]
];
