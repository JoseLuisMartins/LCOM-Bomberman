var searchData=
[
  ['setdefaultposition',['setDefaultPosition',['../group__mouse.html#ga0eeb70e562d104178eea9d7a7c9c3db3',1,'setDefaultPosition(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga0eeb70e562d104178eea9d7a7c9c3db3',1,'setDefaultPosition(mouse_t *m):&#160;mouse.c']]],
  ['setdone',['setDone',['../group__mouse.html#ga949570c2f606d21c94e84bb06199d14e',1,'setDone(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga949570c2f606d21c94e84bb06199d14e',1,'setDone(mouse_t *m):&#160;mouse.c']]],
  ['setpackagevalues',['setPackageValues',['../mouse_8c.html#a3d5b69daa5ad826094acda0c435fe370',1,'setPackageValues():&#160;mouse.c'],['../group__mouse.html#ga3d5b69daa5ad826094acda0c435fe370',1,'setPackageValues():&#160;mouse.h']]],
  ['setpixel',['setPixel',['../group__video__gr.html#gabfeab48cef4571cbff64cf43b0aec4ce',1,'setPixel(unsigned short x, unsigned short y, unsigned long color, int buffer):&#160;video_gr.c'],['../group__video__gr.html#gabfeab48cef4571cbff64cf43b0aec4ce',1,'setPixel(unsigned short x, unsigned short y, unsigned long color, int buffer):&#160;video_gr.c']]],
  ['settings_5fmenu',['settings_menu',['../group__menu.html#ga9449f238d7325c9ea68c2d551cda1235',1,'settings_menu(Settings *setting):&#160;menu.c'],['../group__menu.html#ga9449f238d7325c9ea68c2d551cda1235',1,'settings_menu(Settings *setting):&#160;menu.c']]],
  ['singleplayer',['Singleplayer',['../group___bomberman.html#gad12f50a2fb8b02c1bb7efef2987b748a',1,'Singleplayer():&#160;Bomberman.c'],['../group___bomberman.html#gad12f50a2fb8b02c1bb7efef2987b748a',1,'Singleplayer():&#160;Bomberman.c']]],
  ['swapthirdbuffer',['swapThirdBuffer',['../group__video__gr.html#ga527b0aa49cc82124b114547f1cb69ef7',1,'swapThirdBuffer():&#160;video_gr.c'],['../group__video__gr.html#ga527b0aa49cc82124b114547f1cb69ef7',1,'swapThirdBuffer():&#160;video_gr.c']]],
  ['swapvideomem',['swapVideoMem',['../group__video__gr.html#ga3567344149b4f7204ed3c9959f32d264',1,'swapVideoMem():&#160;video_gr.c'],['../group__video__gr.html#ga3567344149b4f7204ed3c9959f32d264',1,'swapVideoMem():&#160;video_gr.c']]],
  ['synchronize',['synchronize',['../mouse_8c.html#aff3d740b08aeb65e24d4ccd5d55695b2',1,'synchronize(unsigned long byte):&#160;mouse.c'],['../group__mouse.html#gaff3d740b08aeb65e24d4ccd5d55695b2',1,'synchronize(unsigned long byte):&#160;mouse.h']]]
];
