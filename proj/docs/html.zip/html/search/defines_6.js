var searchData=
[
  ['ibf',['IBF',['../i8042_8h.html#a3c48b10907056351582baf9f6478598e',1,'i8042.h']]],
  ['initial_5fx',['INITIAL_X',['../mouse_8c.html#a6752dd4b26e986973fbbc8e18423a476',1,'mouse.c']]],
  ['initial_5fy',['INITIAL_Y',['../mouse_8c.html#ac9cab6d769fb246bda2640057d66ce8f',1,'mouse.c']]],
  ['irq_5f1',['IRQ_1',['../i8042_8h.html#a860f5e9dad920680831e9464d68d9320',1,'i8042.h']]],
  ['irq_5fmouse',['IRQ_MOUSE',['../i8042_8h.html#a32ffe73ffc337fbec467ea02948591af',1,'i8042.h']]]
];
