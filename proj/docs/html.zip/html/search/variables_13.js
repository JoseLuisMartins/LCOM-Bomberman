var searchData=
[
  ['v_5fres',['v_res',['../video__gr_8c.html#a5bda1b499253a8fbf3cab646f8760391',1,'video_gr.c']]],
  ['vbesignature',['VbeSignature',['../struct____attribute____.html#afd3a8744ce19caa07755c2604cce884c',1,'__attribute__']]],
  ['vbeversion',['VbeVersion',['../struct____attribute____.html#a7b9fef89774326b46f9481cbd9a397d3',1,'__attribute__']]],
  ['velocity_5fboost',['velocity_boost',['../structplayer.html#aabbf947576c03c53362174258c279b29',1,'player']]],
  ['velocity_5fcounter',['velocity_counter',['../structplayer.html#a49b366e08fd8d98e65dfe93e78a463ec',1,'player']]],
  ['velocity_5ffaded_5fsb',['velocity_faded_sb',['../_bomberman_8c.html#af47e7c1e59e347ec85ae3e0daf754fb8',1,'Bomberman.c']]],
  ['velocity_5fpower_5fup',['velocity_power_up',['../structmap.html#a95846b9209d28ea94e28bfbecae1e004',1,'map::velocity_power_up()'],['../map_8c.html#a95846b9209d28ea94e28bfbecae1e004',1,'velocity_power_up():&#160;map.c']]],
  ['velocity_5fsb',['velocity_sb',['../_bomberman_8c.html#a15a0bec6b5d6def19e088d38473ea3d2',1,'Bomberman.c']]],
  ['vert_5flength',['vert_length',['../mouse_8c.html#a1e57a2d5da8e504128df0a97db3ba029',1,'mouse.c']]],
  ['video_5fmem',['video_mem',['../video__gr_8c.html#a93a24e067b9083bed6fb5c0336fd7a01',1,'video_gr.c']]],
  ['videomodeptr',['VideoModePtr',['../struct____attribute____.html#a9e9359abdabe91f62795aa14aaecd800',1,'__attribute__']]],
  ['virtual',['virtual',['../structmmap__t.html#a6a0ea2231d30f2b025e0c4b9f12dd6db',1,'mmap_t']]]
];
