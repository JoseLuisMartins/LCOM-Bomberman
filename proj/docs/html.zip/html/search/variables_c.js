var searchData=
[
  ['ncolors',['nColors',['../struct_bitmap_info_header.html#aed4506bad904845183194f199f1bdb98',1,'BitmapInfoHeader']]],
  ['number_5fplayers',['number_players',['../_player_8c.html#aad4e3d3b51fe45abc7c8fd493411f5d7',1,'Player.c']]],
  ['numberofbanks',['NumberOfBanks',['../struct____attribute____.html#aa955c03441b6d3e55b2ba4be4dae56a2',1,'__attribute__']]],
  ['numberofimagepages',['NumberOfImagePages',['../struct____attribute____.html#a7033bb4cac6dc49f68ca4df855151e09',1,'__attribute__']]],
  ['numberofplanes',['NumberOfPlanes',['../struct____attribute____.html#a51268efaac55d78e17263aff9a447998',1,'__attribute__']]],
  ['numvictories',['numVictories',['../structplayer.html#a6f7319b7f1019edf46696fed152188df',1,'player']]]
];
