var searchData=
[
  ['limits',['Limits',['../struct_limits.html',1,'']]]
];
