var searchData=
[
  ['init',['INIT',['../mouse_8c.html#aa0aafed44fec19806d8f9ad834be1248a0cb1b2c6a7db1f1084886c98909a3f36',1,'mouse.c']]],
  ['invalid_5fdirection',['INVALID_DIRECTION',['../utilities_8h.html#aa268a41a13430b18e933ed40207178d0a56189c1e24c9aabb9a2048c9436b7e1a',1,'utilities.h']]]
];
