var searchData=
[
  ['update_5fbomb',['update_bomb',['../group__bomb.html#gac711c3f48d1a02a8b764744f84f15d7b',1,'update_bomb(bomb_t *b):&#160;bomb.c'],['../group__bomb.html#gac711c3f48d1a02a8b764744f84f15d7b',1,'update_bomb(bomb_t *b):&#160;bomb.c']]],
  ['update_5fmap',['update_map',['../group__map.html#gad2518d76b9d233f4603c8d5b11ed79f1',1,'update_map(map_t *m, bomb_t *b):&#160;map.c'],['../group__map.html#gad2518d76b9d233f4603c8d5b11ed79f1',1,'update_map(map_t *m, bomb_t *b):&#160;map.c']]],
  ['update_5fmouse',['update_mouse',['../group__mouse.html#ga86b11ed6010305df2e158227601ff925',1,'update_mouse(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga86b11ed6010305df2e158227601ff925',1,'update_mouse(mouse_t *m):&#160;mouse.c']]],
  ['update_5fplayer',['update_player',['../group__player.html#gadb3480833b2d03fa8b719cde8db98111',1,'update_player(player_t *player, int *teclas_player, map_t *map):&#160;Player.c'],['../group__player.html#gadb3480833b2d03fa8b719cde8db98111',1,'update_player(player_t *player, int *teclas_player, map_t *map):&#160;Player.c']]],
  ['updateplayerposition',['updatePlayerPosition',['../group__player.html#gaa89daa88c97e471982a40465b2017319',1,'updatePlayerPosition(player_t *player):&#160;Player.c'],['../group__player.html#gaa89daa88c97e471982a40465b2017319',1,'updatePlayerPosition(player_t *player):&#160;Player.c']]]
];
