var searchData=
[
  ['icon',['icon',['../structmouse.html#a8881a8dd161b9dbe5fe03065977349da',1,'mouse']]],
  ['imagesize',['imageSize',['../struct_bitmap_info_header.html#adcd57a0168319e747bc8099218d3822c',1,'BitmapInfoHeader']]],
  ['importantcolors',['importantColors',['../struct_bitmap_info_header.html#a8f7abfbc446b12f385d2b42c3b4fd9b0',1,'BitmapInfoHeader']]]
];
