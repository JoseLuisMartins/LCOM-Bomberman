var searchData=
[
  ['game_5fstate',['GAME_STATE',['../utilities_8h.html#a4cc39f049df62b331976f9a4482bd3ea',1,'utilities.h']]]
];
