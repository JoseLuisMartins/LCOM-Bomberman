var searchData=
[
  ['date_5finfo_5ft',['date_info_t',['../structdate__info__t.html',1,'']]]
];
