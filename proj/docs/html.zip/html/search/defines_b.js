var searchData=
[
  ['obf',['OBF',['../i8042_8h.html#a45967c9e25447ba853cf6fb4ac545fe6',1,'i8042.h']]],
  ['out_5fbuf',['OUT_BUF',['../i8042_8h.html#acfb42dde389e8ca36ab267002fbf5c6a',1,'i8042.h']]]
];
