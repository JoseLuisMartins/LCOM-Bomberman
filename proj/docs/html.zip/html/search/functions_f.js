var searchData=
[
  ['wait_5fvalid_5frtc',['wait_valid_rtc',['../group__rtc.html#ga74509feeac5ce275416f0239f4d92776',1,'wait_valid_rtc():&#160;rtc.c'],['../group__rtc.html#ga74509feeac5ce275416f0239f4d92776',1,'wait_valid_rtc():&#160;rtc.c']]]
];
