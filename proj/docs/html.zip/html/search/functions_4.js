var searchData=
[
  ['get_5fkey_5fdirection',['get_key_direction',['../group___bomberman.html#ga91109312457625ef85b90ec9c48acb97',1,'get_key_direction(int teclas_player[]):&#160;Bomberman.c'],['../group___bomberman.html#ga91109312457625ef85b90ec9c48acb97',1,'get_key_direction(int teclas_player[]):&#160;Bomberman.c']]],
  ['getblocodestrutivel',['getBlocoDestrutivel',['../group__map.html#ga7c6ec8e707fb51ec50a059e54e54122a',1,'getBlocoDestrutivel(map_t *m):&#160;map.c'],['../group__map.html#ga7c6ec8e707fb51ec50a059e54e54122a',1,'getBlocoDestrutivel(map_t *m):&#160;map.c']]],
  ['getcurrentdate',['getCurrentDate',['../group__rtc.html#ga529ac752314d389c5424c46c68bbae83',1,'getCurrentDate(date_info_t *date):&#160;rtc.c'],['../group__rtc.html#ga529ac752314d389c5424c46c68bbae83',1,'getCurrentDate(date_info_t *date):&#160;rtc.c']]],
  ['getcurrenttime',['getCurrentTime',['../group__rtc.html#gaa7be7d859a6270fe370fe00e69884adf',1,'getCurrentTime(time_info_t *time):&#160;rtc.c'],['../group__rtc.html#gaa7be7d859a6270fe370fe00e69884adf',1,'getCurrentTime(time_info_t *time):&#160;rtc.c']]],
  ['getdone',['getDone',['../group__mouse.html#ga810689bd36f87502f216370be2dcd4be',1,'getDone(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga810689bd36f87502f216370be2dcd4be',1,'getDone(mouse_t *m):&#160;mouse.c']]],
  ['getdraw',['getDraw',['../group__mouse.html#gaa49f74f4ffefdbfb03368fa93527a5c9',1,'getDraw(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#gaa49f74f4ffefdbfb03368fa93527a5c9',1,'getDraw(mouse_t *m):&#160;mouse.c']]],
  ['gethorresolution',['getHorResolution',['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c'],['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c']]],
  ['getsecond_5fbuffer',['getSecond_Buffer',['../group__video__gr.html#gac59c35f54ed9910f5fb4eb92e0375fe4',1,'getSecond_Buffer():&#160;video_gr.c'],['../group__video__gr.html#gac59c35f54ed9910f5fb4eb92e0375fe4',1,'getSecond_Buffer():&#160;video_gr.c']]],
  ['getthird_5fbuffer',['getThird_Buffer',['../group__video__gr.html#ga92b306fc0fc41d0178fb7e6e9435711d',1,'getThird_Buffer():&#160;video_gr.c'],['../group__video__gr.html#ga92b306fc0fc41d0178fb7e6e9435711d',1,'getThird_Buffer():&#160;video_gr.c']]],
  ['getverresolution',['getVerResolution',['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c'],['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c']]]
];
