var searchData=
[
  ['vbe_5fget_5finfo_5fblock',['vbe_get_info_block',['../vbe_8c.html#ae0d38ab6ddc240e90b85031d21814264',1,'vbe.c']]],
  ['vbe_5fget_5fmode_5finfo',['vbe_get_mode_info',['../group__vbe.html#ga4ef3234e41f2050bc094a22049b69e45',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_p):&#160;vbe.c'],['../group__vbe.html#ga4ef3234e41f2050bc094a22049b69e45',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_p):&#160;vbe.c']]],
  ['vg_5fexit',['vg_exit',['../group__video__gr.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit():&#160;video_gr.c'],['../group__video__gr.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit(void):&#160;video_gr.c']]],
  ['vg_5finit',['vg_init',['../group__video__gr.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c'],['../group__video__gr.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c']]]
];
