var searchData=
[
  ['friday',['FRIDAY',['../group__rtc.html#gga001a7dedaa25d8d3062cbd28fefcb29fa8f589731fd90a9890c0df9a9c3f96131',1,'rtc.h']]]
];
