var searchData=
[
  ['resetdone',['resetDone',['../group__mouse.html#ga3c950a5f8dfc0efcd8bec872d8bf8233',1,'resetDone(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga3c950a5f8dfc0efcd8bec872d8bf8233',1,'resetDone(mouse_t *m):&#160;mouse.c']]],
  ['resetplayer',['resetPlayer',['../group__player.html#gaf9dfc803408219caeb2ae9aeae8b1e21',1,'resetPlayer(player_t *player, int x, int y):&#160;Player.c'],['../group__player.html#gaf9dfc803408219caeb2ae9aeae8b1e21',1,'resetPlayer(player_t *player, int x, int y):&#160;Player.c']]],
  ['rtc_5fdisable_5fint',['rtc_disable_int',['../group__rtc.html#ga0f8758bf0df6766696104c3be6c0c6ea',1,'rtc_disable_int():&#160;rtc.c'],['../group__rtc.html#ga0f8758bf0df6766696104c3be6c0c6ea',1,'rtc_disable_int():&#160;rtc.c']]],
  ['rtc_5fenable_5fint',['rtc_enable_int',['../group__rtc.html#ga8d098a183fdb5fc38da0335041c4d3db',1,'rtc_enable_int():&#160;rtc.c'],['../group__rtc.html#ga8d098a183fdb5fc38da0335041c4d3db',1,'rtc_enable_int():&#160;rtc.c']]]
];
