var searchData=
[
  ['resend',['RESEND',['../i8042_8h.html#a92f67631ef5a97e4a266c15bc710776d',1,'i8042.h']]],
  ['rtc_5fhook_5fnotification',['RTC_HOOK_NOTIFICATION',['../i8042_8h.html#aaa71c3d45782afe29955ebc1bfb90f57',1,'i8042.h']]]
];
