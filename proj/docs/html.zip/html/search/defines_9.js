var searchData=
[
  ['mouse_5fhook_5fnotification',['MOUSE_HOOK_NOTIFICATION',['../i8042_8h.html#aba6f3b5c09b96d58765e05b1e7f94a8e',1,'i8042.h']]],
  ['msb_5fextra_5fbyte',['MSB_EXTRA_BYTE',['../i8042_8h.html#aaefd68342069ea5ae9d7516c6da7a7ed',1,'i8042.h']]]
];
