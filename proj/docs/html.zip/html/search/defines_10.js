var searchData=
[
  ['video_5fmem',['VIDEO_MEM',['../utilities_8h.html#a75bd6d80644f73b99985a3046e3f39cb',1,'utilities.h']]]
];
