var searchData=
[
  ['best_5fof_5f1',['BEST_OF_1',['../utilities_8h.html#a4cc39f049df62b331976f9a4482bd3eaa10637dacf37521ef2e9418d73ab0bedd',1,'utilities.h']]],
  ['best_5fof_5f3',['BEST_OF_3',['../utilities_8h.html#a4cc39f049df62b331976f9a4482bd3eaac28e5ba19cf72c1f01e44c18b230178e',1,'utilities.h']]],
  ['best_5fof_5f5',['BEST_OF_5',['../utilities_8h.html#a4cc39f049df62b331976f9a4482bd3eaae961507ef5766fd97cafbf7fa049fcb1',1,'utilities.h']]]
];
