var searchData=
[
  ['settings',['Settings',['../struct_settings.html',1,'']]],
  ['sprite',['Sprite',['../struct_sprite.html',1,'']]]
];
