var searchData=
[
  ['kbc_5fcmd_5freg',['KBC_CMD_REG',['../i8042_8h.html#a6d57c7927a10f638c83046b52c8caac9',1,'i8042.h']]],
  ['kbd_5fcmd_5freg',['KBD_CMD_REG',['../i8042_8h.html#a6e8e75268b1c463037aa9abcbef3d44b',1,'i8042.h']]],
  ['kbd_5fhook_5fnotification',['KBD_HOOK_NOTIFICATION',['../i8042_8h.html#ad13e05f3ac3710e1d2cf1b3127365d43',1,'i8042.h']]],
  ['kbd_5fswitch_5fled_5fcmd',['KBD_SWITCH_LED_CMD',['../i8042_8h.html#a7da9db812ad45106226ed470b322f123',1,'i8042.h']]]
];
