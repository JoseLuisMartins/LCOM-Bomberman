var searchData=
[
  ['uip_5fset',['UIP_SET',['../group__rtc.html#ga908fb8fa91820d81398ecbea38fb5dcd',1,'rtc.h']]],
  ['up',['up',['../struct_sprite.html#ab144104b568e9b0a64e822280c0b6f5c',1,'Sprite::up()'],['../utilities_8h.html#aa268a41a13430b18e933ed40207178d0aba595d8bca8bc5e67c37c0a9d89becfa',1,'UP():&#160;utilities.h']]],
  ['up_5findex',['UP_INDEX',['../group__player.html#ga8c196c428d7f82be619f28055f11d171',1,'Player.h']]],
  ['upblue',['upBlue',['../sprite_8c.html#a6c52f56f9a550f845cae60ebfbabdf88',1,'sprite.c']]],
  ['update_5fbomb',['update_bomb',['../group__bomb.html#gac711c3f48d1a02a8b764744f84f15d7b',1,'update_bomb(bomb_t *b):&#160;bomb.c'],['../group__bomb.html#gac711c3f48d1a02a8b764744f84f15d7b',1,'update_bomb(bomb_t *b):&#160;bomb.c']]],
  ['update_5fmap',['update_map',['../group__map.html#gad2518d76b9d233f4603c8d5b11ed79f1',1,'update_map(map_t *m, bomb_t *b):&#160;map.c'],['../group__map.html#gad2518d76b9d233f4603c8d5b11ed79f1',1,'update_map(map_t *m, bomb_t *b):&#160;map.c']]],
  ['update_5fmouse',['update_mouse',['../group__mouse.html#ga86b11ed6010305df2e158227601ff925',1,'update_mouse(mouse_t *m):&#160;mouse.c'],['../group__mouse.html#ga86b11ed6010305df2e158227601ff925',1,'update_mouse(mouse_t *m):&#160;mouse.c']]],
  ['update_5fplayer',['update_player',['../group__player.html#gadb3480833b2d03fa8b719cde8db98111',1,'update_player(player_t *player, int *teclas_player, map_t *map):&#160;Player.c'],['../group__player.html#gadb3480833b2d03fa8b719cde8db98111',1,'update_player(player_t *player, int *teclas_player, map_t *map):&#160;Player.c']]],
  ['updateplayerposition',['updatePlayerPosition',['../group__player.html#gaa89daa88c97e471982a40465b2017319',1,'updatePlayerPosition(player_t *player):&#160;Player.c'],['../group__player.html#gaa89daa88c97e471982a40465b2017319',1,'updatePlayerPosition(player_t *player):&#160;Player.c']]],
  ['upwhite',['upWhite',['../sprite_8c.html#a7f6d790c691e5955e7ee55cc35b2bc57',1,'sprite.c']]],
  ['utilities_2eh',['utilities.h',['../utilities_8h.html',1,'']]]
];
