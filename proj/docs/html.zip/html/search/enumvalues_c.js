var searchData=
[
  ['thursday',['THURSDAY',['../group__rtc.html#gga001a7dedaa25d8d3062cbd28fefcb29fab4bfd6f883437c6cf31486dcf03ce0ff',1,'rtc.h']]],
  ['tuesday',['TUESDAY',['../group__rtc.html#gga001a7dedaa25d8d3062cbd28fefcb29fa347c4455723bb1bc2709647607a2b282',1,'rtc.h']]]
];
